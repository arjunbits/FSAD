export const { JWT_SECRET } = process.env;
export const JWT_EXPIRES_IN = 86400;
