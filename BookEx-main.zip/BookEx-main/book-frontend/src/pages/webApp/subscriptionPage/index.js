import SubscriptionPage from './SubscriptionPage';

export {
  SubscriptionPage,
};
