import MainPage from './MainPage';
import BookmateCard from './BookmateCard';

export {
  MainPage,
  BookmateCard,
};
