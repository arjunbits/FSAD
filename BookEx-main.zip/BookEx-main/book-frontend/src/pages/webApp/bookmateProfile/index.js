import BookmateProfilePage from './BookmateProfilePage';
import CommentSection from './CommentSection';

export {
  BookmateProfilePage, CommentSection,
};
