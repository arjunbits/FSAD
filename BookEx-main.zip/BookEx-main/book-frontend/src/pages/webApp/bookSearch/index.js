import BookSearchResultPage from './bookResultPage';

export {
  BookSearchResultPage,
};
