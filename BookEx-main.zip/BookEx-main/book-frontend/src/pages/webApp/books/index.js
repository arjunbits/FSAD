import BookDetails from './BookDetails';
import UserList from './UserList';

export {
  BookDetails,
  UserList,
};
