import BookmatesPage from './BookmatesPage';

export {
  BookmatesPage,
};
