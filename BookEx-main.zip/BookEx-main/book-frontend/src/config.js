export default {
  BACKEND_URL: process.env.REACT_APP_BACKEND_URL,
  PAYPAL_CLIENT_ID: process.env.REACT_APP_PAYPAL_CLIENT_ID,
  AUTH_KEY: 'jwt_auth',
  JWT_AGE: 86400,
};
