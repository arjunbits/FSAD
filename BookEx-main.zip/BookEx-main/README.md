### Tech Stack

The project uses MERN stack.

- Frontend: React.js
- Backend: Express.js, Node.js
- Database: MongoDB

- Fullstack features
  - User profile create & update
  - Authentication & authorization with JWT
  - Exchange order process and detail page
